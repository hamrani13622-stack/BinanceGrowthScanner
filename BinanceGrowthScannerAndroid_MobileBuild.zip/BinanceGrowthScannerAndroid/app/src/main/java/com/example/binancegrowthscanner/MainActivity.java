package com.example.binancegrowthscanner;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String BASE = "https://api.binance.com";
    private static final String CHANNEL_ID = "crypto_signals";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private LinearLayout content;
    private TextView status;
    private Button scanButton;
    private boolean scanning = false;

    static class CoinSignal {
        String symbol;
        double price, change7d, rsi, volumeRatio, atrPct, stop, target1, target2;
        int score;
        List<String> reasons = new ArrayList<>();
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        requestNotificationPermissionIfNeeded();
        buildUi();
        status.setText("آماده اسکن بازار بایننس اسپات");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(12, 18, 30));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(22), dp(18), dp(24));
        scroll.addView(content);

        TextView title = new TextView(this);
        title.setText("Crypto Growth Scanner");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        content.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("اسکن رمزارزهای بایننس • افق ۱ تا ۷ روز • فقط سیگنال");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(6), 0, dp(16));
        content.addView(subtitle);

        scanButton = new Button(this);
        scanButton.setText("شروع اسکن");
        content.addView(scanButton);

        status = new TextView(this);
        status.setTextColor(Color.rgb(160, 190, 220));
        status.setTextSize(14);
        status.setPadding(0, dp(12), 0, dp(12));
        content.addView(status);

        TextView disclaimer = new TextView(this);
        disclaimer.setText("امتیازها احتمال واقعی رشد نیستند. این برنامه سفارش معامله ثبت نمی‌کند. حد ضرر ممکن است به‌علت لغزش قیمت دقیقاً اجرا نشود.");
        disclaimer.setTextColor(Color.rgb(255, 202, 120));
        disclaimer.setTextSize(13);
        disclaimer.setPadding(dp(10), dp(10), dp(10), dp(10));
        disclaimer.setBackgroundColor(Color.rgb(40, 35, 27));
        content.addView(disclaimer);

        scanButton.setOnClickListener(v -> startScan());
        setContentView(scroll);
    }

    private void startScan() {
        if (scanning) return;
        scanning = true;
        scanButton.setEnabled(false);
        status.setText("دریافت داده‌های عمومی بایننس...");
        // Keep UI responsive while network calls run off the main thread.
        executor.execute(() -> {
            try {
                List<CoinSignal> signals = scanMarket();
                runOnUiThread(() -> showResults(signals));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("خطا در دریافت داده: " + e.getMessage()
                        + "\nاتصال اینترنت یا دسترسی API بایننس را بررسی کن."));
            } finally {
                runOnUiThread(() -> {
                    scanning = false;
                    scanButton.setEnabled(true);
                });
            }
        });
    }

    private List<CoinSignal> scanMarket() throws Exception {
        JSONArray tickers = new JSONArray(httpGet(BASE + "/api/v3/ticker/24hr"));
        List<JSONObject> candidates = new ArrayList<>();
        for (int i = 0; i < tickers.length(); i++) {
            JSONObject t = tickers.getJSONObject(i);
            String symbol = t.optString("symbol", "");
            if (!symbol.endsWith("USDT") || symbol.contains("UPUSDT") || symbol.contains("DOWNUSDT")
                    || symbol.contains("BULLUSDT") || symbol.contains("BEARUSDT")) continue;
            double qv = t.optDouble("quoteVolume", 0);
            if (qv >= 2_000_000) candidates.add(t);
        }
        Collections.sort(candidates, (a, b) -> Double.compare(b.optDouble("quoteVolume", 0), a.optDouble("quoteVolume", 0)));
        List<CoinSignal> out = new ArrayList<>();
        int count = Math.min(35, candidates.size()); // keep API use moderate
        for (int i = 0; i < count; i++) {
            JSONObject t = candidates.get(i);
            String symbol = t.optString("symbol");
            try {
                CoinSignal s = analyze(symbol, t.optDouble("lastPrice", 0));
                if (s != null) out.add(s);
                Thread.sleep(120); // gentle pacing for public API
            } catch (Exception ignored) { }
        }
        Collections.sort(out, (a, b) -> Integer.compare(b.score, a.score));
        return out;
    }

    private CoinSignal analyze(String symbol, double livePrice) throws Exception {
        JSONArray arr = new JSONArray(httpGet(BASE + "/api/v3/klines?symbol=" + symbol + "&interval=4h&limit=220"));
        int n = arr.length() - 1; // ignore currently forming candle
        if (n < 60 || livePrice <= 0) return null;
        double[] close = new double[n], high = new double[n], low = new double[n], volume = new double[n];
        for (int i = 0; i < n; i++) {
            JSONArray c = arr.getJSONArray(i);
            close[i] = Double.parseDouble(c.getString(4));
            high[i] = Double.parseDouble(c.getString(2));
            low[i] = Double.parseDouble(c.getString(3));
            volume[i] = Double.parseDouble(c.getString(5));
        }
        double ema20 = ema(close, 20), ema50 = ema(close, 50);
        double ema200 = n >= 200 ? ema(close, 200) : 0;
        double rsi = rsi(close, 14);
        double atr = atr(high, low, close, 14);
        double avgVol = 0;
        for (int i = n - 20; i < n; i++) avgVol += volume[i];
        avgVol /= 20.0;
        double volRatio = avgVol > 0 ? volume[n - 1] / avgVol : 0;
        double change7d = close[n - 1] / close[Math.max(0, n - 43)] * 100.0 - 100.0;
        int score = 0;
        List<String> reasons = new ArrayList<>();
        if (close[n - 1] > ema20) { score += 10; reasons.add("قیمت بالای EMA20"); }
        if (ema20 > ema50) { score += 15; reasons.add("EMA20 بالای EMA50"); }
        if (n >= 200 && close[n - 1] > ema200) { score += 10; reasons.add("قیمت بالای EMA200"); }
        if (rsi >= 52 && rsi <= 68) { score += 15; reasons.add(String.format(Locale.US, "RSI متعادل %.1f", rsi)); }
        else if (rsi >= 45 && rsi < 52) { score += 7; reasons.add(String.format(Locale.US, "RSI رو به بهبود %.1f", rsi)); }
        if (volRatio >= 1.5) { score += 20; reasons.add(String.format(Locale.US, "حجم %.1fx میانگین", volRatio)); }
        else if (volRatio >= 1.2) { score += 10; reasons.add(String.format(Locale.US, "افزایش حجم %.1fx", volRatio)); }
        if (change7d > 0) { score += 10; reasons.add(String.format(Locale.US, "بازده ۷روزه مثبت %.1f%%", change7d)); }
        double prevHigh = 0;
        for (int i = n - 21; i < n - 1; i++) prevHigh = Math.max(prevHigh, high[i]);
        if (close[n - 1] > prevHigh) { score += 20; reasons.add("شکست سقف ۲۰ کندل قبلی"); }
        if (rsi > 75) { score -= 15; reasons.add("هشدار بیش‌خرید"); }
        double atrPct = atr / close[n - 1] * 100;
        if (atrPct > 8) { score -= 10; reasons.add("نوسان بسیار بالا"); }
        score = Math.max(0, Math.min(100, score));

        double risk = Math.max(2 * atr, livePrice * 0.025);
        CoinSignal s = new CoinSignal();
        s.symbol = symbol; s.price = livePrice; s.score = score; s.change7d = change7d;
        s.rsi = rsi; s.volumeRatio = volRatio; s.atrPct = atrPct;
        s.stop = livePrice - risk; s.target1 = livePrice + 1.5 * risk; s.target2 = livePrice + 2 * risk;
        s.reasons = reasons;
        return s;
    }

    private double ema(double[] x, int period) {
        double k = 2.0 / (period + 1.0), value = x[0];
        for (int i = 1; i < x.length; i++) value = x[i] * k + value * (1 - k);
        return value;
    }

    private double rsi(double[] close, int period) {
        double gain = 0, loss = 0;
        int start = Math.max(1, close.length - period);
        for (int i = start; i < close.length; i++) {
            double d = close[i] - close[i - 1];
            if (d > 0) gain += d; else loss -= d;
        }
        int count = close.length - start;
        if (count <= 0) return 50;
        gain /= count; loss /= count;
        if (loss == 0) return 100;
        return 100 - 100 / (1 + gain / loss);
    }

    private double atr(double[] high, double[] low, double[] close, int period) {
        int start = Math.max(1, close.length - period);
        double total = 0;
        for (int i = start; i < close.length; i++) {
            total += Math.max(high[i] - low[i], Math.max(Math.abs(high[i] - close[i - 1]), Math.abs(low[i] - close[i - 1])));
        }
        return total / Math.max(1, close.length - start);
    }

    private String httpGet(String urlString) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(12000);
        conn.setRequestProperty("User-Agent", "CryptoGrowthScannerAndroid/1.0");
        try {
            int code = conn.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + sb);
            return sb.toString();
        } finally {
            conn.disconnect();
        }
    }

    private void showResults(List<CoinSignal> signals) {
        // Remove old results but keep header, button, status, disclaimer.
        while (content.getChildCount() > 5) content.removeViewAt(5);
        status.setText("آخرین اسکن: " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date())
                + " • تعداد نتایج: " + signals.size());
        boolean alerted = false;
        for (CoinSignal s : signals) {
            TextView card = new TextView(this);
            StringBuilder reasons = new StringBuilder();
            for (String r : s.reasons) reasons.append("• ").append(r).append("\n");
            card.setText(String.format(Locale.US,
                    "%s  |  امتیاز %d/100\nقیمت: %s USDT\nتغییر ۷روزه: %.2f%%  • RSI: %.1f  • حجم: %.2fx\nحد ضرر: %s\nهدف ۱: %s\nهدف ۲: %s\n%s",
                    s.symbol, s.score, fmt(s.price), s.change7d, s.rsi, s.volumeRatio,
                    fmt(s.stop), fmt(s.target1), fmt(s.target2), reasons.toString()));
            card.setTextColor(Color.WHITE);
            card.setTextSize(14);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setBackgroundColor(s.score >= 65 ? Color.rgb(25, 57, 49) : Color.rgb(27, 36, 52));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(8), 0, dp(4));
            content.addView(card, lp);
            if (s.score >= 65 && !alerted) {
                showNotification(s);
                alerted = true; // at most one notification per manual scan
            }
        }
        if (signals.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("نتیجه‌ای پیدا نشد. بعداً دوباره اسکن کن.");
            empty.setTextColor(Color.WHITE);
            content.addView(empty);
        }
    }

    private void showNotification(CoinSignal s) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(this, CHANNEL_ID)
                : new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("فرصت احتمالی: " + s.symbol)
                .setContentText("امتیاز " + s.score + "/100 • حد ضرر: " + fmt(s.stop))
                .setStyle(new android.app.Notification.BigTextStyle().bigText(
                        "قیمت: " + fmt(s.price) + " USDT\nامتیاز: " + s.score + "/100\nحد ضرر: " + fmt(s.stop)
                                + "\nهدف ۱: " + fmt(s.target1) + "\nهدف ۲: " + fmt(s.target2)))
                .setAutoCancel(true);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((int) (System.currentTimeMillis() % Integer.MAX_VALUE), b.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Crypto signals", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("هشدار سیگنال‌های اسکنر رمزارز");
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 501);
        }
    }

    private String fmt(double v) {
        if (v >= 1000) return String.format(Locale.US, "%,.2f", v);
        if (v >= 1) return String.format(Locale.US, "%.4f", v);
        if (v >= 0.01) return String.format(Locale.US, "%.6f", v);
        return String.format(Locale.US, "%.8f", v);
    }
    private int dp(int x) { return (int) (x * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
